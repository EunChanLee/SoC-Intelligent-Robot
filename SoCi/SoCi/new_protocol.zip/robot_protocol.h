#ifndef __ROBOT_PROTOCOL_H__
#define __ROBOT_PROTOCOL_H__

#define START_CODE    0xFF
#define START_CODE1   0x55

typedef enum tag_fsm_state {
	idle,
	start1,
	start2,
	data1,
	data2,
	data3,
	data4,
	buff_check
}fsm_state;

void DelayLoop(int delay_time);
void send_packet(unsigned char Ldata, unsigned char Hdata);
int Motion_ack(unsigned char num);
int exam_rxbuf(void);
void Clear_Buf(void);

#endif

