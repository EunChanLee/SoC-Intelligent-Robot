#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "robot_protocol.h"
#include "uart_api.h"
//////////////////////////////////////////////////// Protocol Test

static unsigned char pnum = 0;

void DelayLoop(int delay_time)
{
	struct timeval start, end;
	long msec;
	gettimeofday(&start, NULL);

	for (;;) {
		gettimeofday(&end, NULL);
		msec = ((end.tv_sec - start.tv_sec) * 1000) + ((end.tv_usec - start.tv_usec) / 1000);
		if (msec > delay_time)
		{
			break;
		}
	}
}

void send_packet(unsigned char Ldata, unsigned char Hdata)
{
	unsigned char packet[6] = { 0 };

	packet[0] = START_CODE;	// Start Byte -> 0xff
	packet[1] = START_CODE1; // Start Byte1 -> 0x55
	packet[2] = Ldata;
	packet[3] = 255 - Ldata;
	packet[4] = Hdata;
	packet[5] = 255 - Hdata;

	uart1_buffer_write(packet, 6);
}

int Motion_ack(unsigned char num)
{
	unsigned char basket[6] = { 0 };
	unsigned char acknum;
	unsigned char acksta;
	int success_flag;
	int toCnt;

	fsm_state state;
	fsm_state state_mem;

	while (1) {
		state = idle;
		state_mem = idle;
		success_flag = 0;
		toCnt = 0;

		send_packet(num, pnum);

		while ((toCnt < 30000) && (success_flag == 0)) {
			switch (state) {
			case idle:
				if (uart1_rxbuf_exist() > 0)
					state = start1;
				else
					toCnt++;
				break;
			case buff_check:
				if (uart1_rxbuf_exist() > 0)
					state = state_mem;
				else
					toCnt++;
				break;
			case start1:
				uart1_buffer_read(basket, 1);
				if (basket[0] == 0xff) {
					state_mem = start2;
					state = buff_check;
				}
				else {
					state = idle;
					toCnt++;
				}
				break;
			case start2:
				uart1_buffer_read(basket + 1, 1);
				if (basket[1] == 0x55) {
					state_mem = data1;
					state = buff_check;
				}
				else {
					state = idle;
					toCnt++;
				}
				break;
			case data1:
				uart1_buffer_read(basket + 2, 1);
				state_mem = data2;
				state = buff_check;
				break;
			case data2:
				uart1_buffer_read(basket + 3, 1);
				state_mem = data3;
				state = buff_check;
				break;
			case data3:
				uart1_buffer_read(basket + 4, 1);
				state_mem = data4;
				state = buff_check;
				break;
			case data4:
				uart1_buffer_read(basket + 5, 1);
				success_flag = 1;
				state = idle;
				break;
			default:
				state = idle;
				toCnt++;
				break;
			}
		}
		
		if (success_flag) {
			acknum = basket[4];
			acksta = basket[2];

			if (acknum == pnum) {
				pnum++;
				break;
			}
		}
	}

	return (int)acksta;
}

int exam_rxbuf(void) {
	int temp = uart1_rxbuf_exist();
	printf("uart_rx_level :%d\n", temp);
	return temp;
}

void Clear_Buf(void)
{
	uart1_rxbuf_clear();
}